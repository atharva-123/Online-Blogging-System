package models;

import java.sql.*;
import services.*;


public class RegisterBranch {
	
	private String branchid;
	private String branchname;
	
	
	
	
	public String getBranchid() {
		return branchid;
	}




	public void setBranchid(String branchid) {
		this.branchid = branchid;
	}




	public String getBranchname() {
		return branchname;
	}




	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}




	public String registerBranch() {
	
	Connection con;
	PreparedStatement pst;
	GetConnection gc = new GetConnection();
	String sts="";
	
	try {
		con=gc.getConnection();
		 
		pst=con.prepareStatement("insert into branches values(?,?);");
		pst.setInt(1, getId());
		pst.setString(2, branchname);
		
		int x= pst.executeUpdate();
		
		if(x>0)
			sts="Success.jsp";
		else
			sts="Failure.jsp";
	}
	catch(Exception ex) {
		System.out.println("err="+ex.getMessage());
		ex.printStackTrace();
		sts="Duplicate.jsp";
	}
	return(sts);
	}
 	public int getId()
    {
 		int mxid=0;
        try
        {Connection con;
    	PreparedStatement pst;
    	GetConnection gc = new GetConnection();
    	
             
            con=gc.getConnection();
          CallableStatement csmt=con.prepareCall("{call getMaxIdBranches()}");
           
             csmt.execute();
            ResultSet rs=csmt.getResultSet();
                        
            boolean auth=false;
            while(rs.next())
            { System.out.println("true");
                auth=true;
                
                mxid=rs.getInt("mxid");
                  
            }
        }
           
         
        catch(Exception ex)
        {
            System.out.println("err="+ex.getMessage());
             
        }
        return mxid+1;
    } 
}
