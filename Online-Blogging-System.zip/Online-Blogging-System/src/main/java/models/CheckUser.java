package models;
import java.sql.*;
import java.util.List;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import services.GetConnection;
import services.JavaFuns;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
 


public class CheckUser {

	private String userid;
	private String pswd;
		
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPswd() {
		return pswd;
	}
	public void setPswd(String pswd) {
		this.pswd = pswd;
	}
	
	public String checkUser(HttpServletRequest request) {
		
		Connection con;
		ResultSet rs;
		String typ,st="";
		GetConnection gc = new GetConnection();
		
		
		try {
			
			//establish connection with mysql
			con=gc.getConnection();
			//query formation
			PreparedStatement pst;
			pst=con.prepareStatement("select * from users where userid=? and pswd=? and userstatus='active' ");
			pst.setString(1,userid );
			pst.setString(2, pswd);
			//query execution	
			rs=pst.executeQuery();
			
			if(rs.next()) { 
				HttpSession sess=request.getSession(true);
				sess.setAttribute("userid",userid);
				sess.setAttribute("usertype", rs.getString("usertype"));
				sess.setAttribute("username", rs.getString("usernm"));
				sess.setAttribute("branch", rs.getString("branch"));
				
				typ=rs.getString("usertype");
				sess.setAttribute("photo", getPhoto(userid, typ));
				LoginTracker lt=new LoginTracker();
				lt.recordLogin(userid, typ);
				if(typ.equals("staff"))
				{
					st="posts";
					sess.setAttribute("sem", "NA");
				}
				else if(typ.equals("student"))
				{
					st="posts";
					JavaFuns jf=new JavaFuns();
					Vector v=jf.getValue("select semester from studentpersonal where userid='"+userid.trim()+"'", 1);
					sess.setAttribute("sem", v.elementAt(0).toString().trim());
				}
				else if(typ.equals("admin"))
					st="approvestudentlist";
				else
					st="posts";
			}
			else
				st="LoginFailure.jsp";
		}
		
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return(st);	
	}
public String getPhoto(String userid,String utype) {
		String photo="common.png";
		Connection con;
		ResultSet rs;
		String typ,st="";
		GetConnection gc = new GetConnection();
		
		
		try {
			
			
			con=gc.getConnection();
			PreparedStatement pst;
			String qr="";
			if(utype.equals("student"))
			{
				qr="select photo from studentpersonal where userid='"+userid+"'";
			}
			else
				qr="select photo from staffpersonal where userid='"+userid+"'";

			pst=con.prepareStatement(qr);
			 
			rs=pst.executeQuery();
			
			if(rs.next()) { 
				photo=rs.getString("photo");
				 
			}
			 
		}
		
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return(photo);	
	}
}
