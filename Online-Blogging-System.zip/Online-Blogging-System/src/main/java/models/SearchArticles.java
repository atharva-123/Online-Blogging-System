package models;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.annotation.MultipartConfig;
import services.*;
import models.*;

@MultipartConfig
public class SearchArticles {

	private String description,path,userid,artid,dt;
	private List<SearchArticles> lstsearch1;
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getArtid() {
		return artid;
	}

	public void setArtid(String artid) {
		this.artid = artid;
	}

	public String getDt() {
		return dt;
	}

	public void setDt(String dt) {
		this.dt = dt;
	}
	
	
public List<SearchArticles> getLstsearch1() {
		return lstsearch1;
	}

	public void setLstsearch1(List<SearchArticles> lstsearch1) {
		this.lstsearch1 = lstsearch1;
	}

public void getSearchResultA(String userid){
		
		GetConnection gc= new GetConnection();
		Connection con;
		PreparedStatement cst;
		ResultSet rs;
		
		lstsearch1=new ArrayList<SearchArticles>();
		
		try {
			
			con=gc.getConnection();
			String qr="select * from articleuploads where artid in (select distinct(aricleid) from articlekeywords where "+getQueryString(userid)+")";
			System.out.println("qr="+qr);
			cst=con.prepareStatement(qr);
			//cst.setString(1, userid);
			cst.execute();
			rs=cst.getResultSet();			
			
			SearchArticles fh;
			
			while(rs.next()) {
				
				fh= new SearchArticles();
				
				fh.setArtid(rs.getString("artid"));
				fh.setUserid(rs.getString("userid"));
				fh.setDescription(rs.getString("description"));
				fh.setPath(rs.getString("path"));
				fh.setDt(rs.getString("date"));
				 
				lstsearch1.add(fh);
				
			}
			
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		 
		
	}

public String getQueryString(String userid){
		
		GetConnection gc= new GetConnection();
		Connection con;
		PreparedStatement cst;
		ResultSet rs;
		 String query="";
		
		try {
			
			con=gc.getConnection();
			
			cst=con.prepareStatement(" select group_concat(concat(\"keyword like '%\",keyword,\"%'\") SEPARATOR ' or ') as squery from userkeywords where userid=?");
			cst.setString(1, userid);
			 
			rs=cst.executeQuery();			
			
			 
			while(rs.next()) {
				  query=rs.getString("squery").toString();
				
			}
			
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		 
		return query;
	}
	
}
