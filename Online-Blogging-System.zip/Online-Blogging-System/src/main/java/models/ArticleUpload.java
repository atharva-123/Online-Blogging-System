package models;

import java.sql.*;
import javax.servlet.annotation.MultipartConfig;
 
import models.*;

@MultipartConfig
public class ArticleUpload {

	private String description;
	
}
