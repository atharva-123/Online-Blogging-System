package models;

import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import services.*;
import models.*;

public class NewArticle {
	
	private String userid;
	private String location;
	private String description,dt,path,category,title,branch,username,sem;
	public String getUserid() {
		return userid;
	}
	
	 

	public String getDt() {
		return dt;
	}



	public void setDt(String dt) {
		this.dt = dt;
	}



	public String getUsername() {
		return username;
	}



	public void setUsername(String username) {
		this.username = username;
	}



	public String getSem() {
		return sem;
	}



	public void setSem(String sem) {
		this.sem = sem;
	}



	public String getTitle() {
		return title;
	}



	public void setTitle(String title) {
		this.title = title;
	}



	public String getBranch() {
		return branch;
	}



	public void setBranch(String branch) {
		this.branch = branch;
	}



	public String getCategory() {
		return category;
	}



	public void setCategory(String category) {
		this.category = category;
	}



	public String getPath() {
		return path;
	}



	public void setPath(String path) {
		this.path = path;
	}



	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	

public List<NewArticle> getArticles(String userid){
	
	Connection con;
	Statement st;
	GetConnection gc = new GetConnection();
	ResultSet rs;
	
	
	List<NewArticle> lst= new ArrayList<NewArticle>();
	 
	try {
		con=gc.getConnection();
		st=con.createStatement();
		String qr="select * from articleuploads where branch='"+branch+"' and (sem='"+sem+"' or sem='na')";
		System.out.println("qr="+qr);
		rs=st.executeQuery(qr);
		
		while(rs.next()) {
			System.out.println("in while");
			NewArticle bl=new NewArticle();
			bl.setDescription(rs.getString("description"));
			bl.setTitle(rs.getString("title"));	
			bl.setUsername(rs.getString("username"));	
			bl.setDt(rs.getString("date"));	
			bl.setPath(rs.getString("path"));	
			lst.add(bl);
			
		}	
		System.out.println("lst size="+lst.size());
			
	}
	catch(Exception ex) {
		ex.printStackTrace();
	}
	
	return (lst);
}
	public String uploadArticle(String userid,String location,String description) {
		
		this.userid=userid;
		this.description= description;
		this.location=location;
		String sts="Failure.jsp";
		Connection con;
		PreparedStatement pst;
		
		GetConnection gc = new GetConnection();
		 
		
		Date date1 = Calendar.getInstance().getTime();  
	    DateFormat dateFormat = new SimpleDateFormat("hhmmss");  
	    String ins = dateFormat.format(date1);
	    JavaFuns jf=new JavaFuns();
	    String qr="select ifnull(max(artid),1000) as mxid from articleuploads ;";
	    Vector v=jf.getValue(qr, 1);
	    int artid=Integer.parseInt(v.elementAt(0).toString().trim())+1;
	    
		try {
		con=gc.getConnection();
		
		pst=con.prepareStatement("insert into articleuploads values(?,?,?,?,?,?,?,?,?,CURDATE(),?)");
		
		pst.setInt(1, artid);
		pst.setString(2, title);
		pst.setString(3, description);
		pst.setString(4, userid);
		pst.setString(5, username);
		pst.setString(6, "staff");
		pst.setString(7, branch);
		pst.setString(8, sem);
		
	
		pst.setString(9, location); 
		pst.setString(10, "NA");
		
		
		int x= pst.executeUpdate();
		 
		
          /*  services.JavaFuns jf1=new services.JavaFuns();
    		String qr1="select v.category,count(*) as cnt from articleView v inner join articleView u on v.artid<>u.artid and u.keyword like concat('%',v.keyword,'%') and u.artid="+artid+" group by category order by cnt desc limit 1";
    		//qr1="select v.category,count(*) as cnt from articleView v where v.keyword in (select keyword from articleView where artid="+artid+")";
    		Vector v1=jf1.getValue(qr1, 2);
    		System.out.println("size="+v1.size());
    		try {
    			category=v1.elementAt(0).toString().trim();
    		if(jf1.execute("update articleuploads set category='"+v1.elementAt(0).toString().trim() +"' where artid="+artid)) {}
    		
    		}
    		catch (Exception e) {
    			// TODO: handle exception
    			System.out.println("err="+e.getMessage());
    			category="Can not Determine";
    		}
		*/
		
		if(x>0)
			sts="Success.jsp";
		else
			sts="Failure.jsp";
		}
		
		catch(Exception ex) {ex.printStackTrace();}
		
		return(sts);
	}
	
}
