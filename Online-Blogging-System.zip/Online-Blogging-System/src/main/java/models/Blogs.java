package models;

import java.sql.*;
import services.*;
import java.util.*;

import org.springframework.web.multipart.MultipartFile;

public class Blogs {
	private String userid;
	private int bid;
	private String title,details,username,sem,photo;
	private String usertype;
	private String branch;
	private String date;
	private MultipartFile file;
	private String sts;
	private List<Blogs> lstsearch;
	 
	 
	 
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getSem() {
		return sem;
	}
	public void setSem(String sem) {
		this.sem = sem;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	public String getSts() {
		return sts;
	}
	public void setSts(String sts) {
		this.sts = sts;
	}
	public List<Blogs> getLstsearch() {
		return lstsearch;
	}
	public void setLstsearch(List<Blogs> lstsearch) {
		this.lstsearch = lstsearch;
	}
public List<Blogs> getBlogsSearch(String br){
		
		GetConnection gc= new GetConnection();
		Connection con;
		Statement st;
		ResultSet rs;
		
		List<Blogs> lst=new ArrayList<Blogs>();
		
		try {
			
			con=gc.getConnection();
			
			st=con.createStatement();
			String qr="select * from blogs where title like '%"+br+"%' order by bid desc";
			rs=st.executeQuery(qr);			
			
			Blogs fh;
			
			while(rs.next()) {
				
				fh= new Blogs();
				
				fh.setBid(rs.getInt("bid"));
				fh.setUserid(rs.getString("userid"));
				fh.setTitle(rs.getString("title"));
				fh.setBranch(rs.getString("branch"));
				fh.setDate(rs.getString("date"));
				fh.setUsertype(rs.getString("usertype"));
				fh.setDetails(rs.getString("details"));
				fh.setUsername(rs.getString("username"));
				fh.setSem(rs.getString("sem"));
				fh.setPhoto(rs.getString("photo"));
				 
				lst.add(fh);
				
			}
			
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return(lst);
		
	} 
	public List<Blogs> getBlogs(String br){
		
		GetConnection gc= new GetConnection();
		Connection con;
		Statement st;
		ResultSet rs;
		
		List<Blogs> lst=new ArrayList<Blogs>();
		
		try {
			
			con=gc.getConnection();
			
			st=con.createStatement();
			
			rs=st.executeQuery("select * from blogs where branch='"+br+"'   order by bid desc;");			
			
			Blogs fh;
			
			while(rs.next()) {
				
				fh= new Blogs();
				
				fh.setBid(rs.getInt("bid"));
				fh.setUserid(rs.getString("userid"));
				fh.setTitle(rs.getString("title"));
				fh.setBranch(rs.getString("branch"));
				fh.setDate(rs.getString("date"));
				fh.setUsertype(rs.getString("usertype"));
				fh.setDetails(rs.getString("details"));
				fh.setUsername(rs.getString("username"));
				fh.setSem(rs.getString("sem"));
				fh.setPhoto(rs.getString("photo"));
				 
				lst.add(fh);
				
			}
			
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return(lst);
		
	} 
public List<Blogs> getBlogs1(String bid1){
		
		GetConnection gc= new GetConnection();
		Connection con;
		Statement st;
		ResultSet rs;
		
		List<Blogs> lst=new ArrayList<Blogs>();
		
		try {
			
			con=gc.getConnection();
			
			st=con.createStatement();
			
			rs=st.executeQuery("select * from blogs where bid="+bid1+"   order by bid desc;");			
			
			Blogs fh;
			
			while(rs.next()) {
				
				fh= new Blogs();
				
				fh.setBid(rs.getInt("bid"));
				fh.setUserid(rs.getString("userid"));
				fh.setTitle(rs.getString("title"));
				fh.setBranch(rs.getString("branch"));
				fh.setDate(rs.getString("date"));
				fh.setUsertype(rs.getString("usertype"));
				fh.setDetails(rs.getString("details"));
				fh.setUsername(rs.getString("username"));
				fh.setSem(rs.getString("sem"));
				fh.setPhoto(rs.getString("photo"));
				 
				lst.add(fh);
				
			}
			
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return(lst);
		
	} 
}
