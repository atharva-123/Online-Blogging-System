package models;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import services.*;


public class Comments {
	
	private int bid,comId;
	private String commtext,userid,username;
	
	 

	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public int getComId() {
		return comId;
	}
	public void setComId(int comId) {
		this.comId = comId;
	}
	public String getCommtext() {
		return commtext;
	}
	public void setCommtext(String commtext) {
		this.commtext = commtext;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String registerComment() {
	
	Connection con;
	PreparedStatement pst;
	GetConnection gc = new GetConnection();
	String sts="";
	
	try {
		con=gc.getConnection();
		 
		pst=con.prepareStatement("insert into comments values(?,?,?,?,?);");
		pst.setInt(1, getId());
		pst.setInt(2, bid);
		pst.setString(3, userid);
		pst.setString(4, username);
		pst.setString(5, commtext);
		
		
		int x= pst.executeUpdate();
		
		if(x>0)
			sts="Success.jsp";
		else
			sts="Failure.jsp";
	}
	catch(Exception ex) {
		System.out.println("err="+ex.getMessage());
		ex.printStackTrace();
		sts="Duplicate.jsp";
	}
	return(sts);
	}
public List<Comments> getComments(int bid){
		
		GetConnection gc= new GetConnection();
		Connection con;
		Statement st;
		ResultSet rs;
		
		List<Comments> lst=new ArrayList<Comments>();
		
		try {
			
			con=gc.getConnection();
			
			st=con.createStatement();
			
			rs=st.executeQuery("select * from comments where bid="+bid+"   order by comId desc;");			
			
			Comments fh;
			
			while(rs.next()) {
				
				fh= new Comments();
				
				fh.setBid(rs.getInt("bid"));
				fh.setUserid(rs.getString("userid"));
				fh.setCommtext(rs.getString("comtext"));
				fh.setUsername(rs.getString("username"));
				fh.setComId(rs.getInt("comId"));
			 
				lst.add(fh);
				
			}
			
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return(lst);
		
	} 
	
 	public int getId()
    {
 		int mxid=0;
        try
        {Connection con;
    	PreparedStatement pst;
    	GetConnection gc = new GetConnection();
    	
             
            con=gc.getConnection();
          CallableStatement csmt=con.prepareCall("{call getMaxIdComments()}");
           
             csmt.execute();
            ResultSet rs=csmt.getResultSet();
                        
            boolean auth=false;
            while(rs.next())
            { System.out.println("true");
                auth=true;
                
                mxid=rs.getInt("mxid");
                  
            }
        }
           
         
        catch(Exception ex)
        {
            System.out.println("err="+ex.getMessage());
             
        }
        return mxid+1;
    } 
}
