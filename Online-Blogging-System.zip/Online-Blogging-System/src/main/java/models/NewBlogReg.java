package models;

import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
 
import services.*;
import services.JavaFuns; 

import java.util.*;
import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

public class NewBlogReg {

	private String userid;
	private int bid;
	private String title,details,username,sem,photo;
	private String usertype;
	private String branch;
	private String date;
	private MultipartFile file;
	private String sts;
	/*
	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
    Date date1 = new Date();  
    String instance=(formatter.format(date));
	*/
	
	Date date1 = Calendar.getInstance().getTime();  
    DateFormat dateFormat = new SimpleDateFormat("hhmmss");  
    String ins = dateFormat.format(date1);
    
	 
	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getSem() {
		return sem;
	}

	public void setSem(String sem) {
		this.sem = sem;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getUsertype() {
		return usertype;
	}

	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getSts() {
		return sts;
	}

	public void setSts(String sts) {
		this.sts = sts;
	}

	public String register() {
		
		
		Connection con;
		GetConnection gc = new GetConnection();
		   
		 
		String sts=""; 
		try {
			
			int j=0;
			int size; 
			con=gc.getConnection(); 
			PreparedStatement pst=con.prepareStatement("insert into blogs values(?,?,?,?,?,?,?,?,?,?);");
			
			pst.setInt(1, bid);
			pst.setString(2, title);
			pst.setString(3, userid);
			pst.setString(4, branch);
			pst.setString(5, usertype);
			Date dt=new Date();
			pst.setString(6, dt.getDate()+"/"+(dt.getMonth()+1)+"/"+(dt.getYear()+1900));
			pst.setString(7,details);
			pst.setString(8,username);
			pst.setString(9,sem);
			pst.setString(10,photo);
			int x=pst.executeUpdate();
			
			if(x>0) {
				sts="Success.jsp";			
					 
					}		
			  		
			
		}
		catch(Exception ex) {
			ex.printStackTrace();
			sts="Failure.jsp";
		}
		
		return(sts);
	}
	
	 
}
