package com.blogging;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.annotation.SessionScope;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
 
import models.ApproveStudents;
 
import models.Blogs;
import models.CheckUser;
import models.Comments;
import models.LoginTracker;
import models.NewArticle;
import models.NewBlogReg;
import models.Pass;
import models.PasswordRecovery;  
import models.RegisterBranch;
import models.SearchArticles;
import models.Staff;
import models.Staff1;
import models.Student; 
import models.ViewStaff;
import models.ViewStudent;
import models.ViewStudentList;
import services.Base64Decoder;
import services.Base64Encoder;
import services.JavaFuns;

@Controller
public class OnlineBloggingController implements ErrorController
{//implements ErrorController
	@RequestMapping("/college")
	public String index()
	{
		return "index.jsp";
	}
	 
	@RequestMapping("/likeQues")
	public String likeQues(HttpServletRequest request)
	{
		try {
		JavaFuns jf=new JavaFuns();
		if(jf.execute("update forumquestions set likes=likes+1 where quid='"+request.getParameter("quId").toString().trim()+"'")) {}
		}
		catch (Exception e) {
			System.out.println("err="+e.getMessage());
			// TODO: handle exception
		}
		return "posts";
	}
	@RequestMapping("/dislikeQues")
	public String dislikeQues(HttpServletRequest request)
	{
		try {
		JavaFuns jf=new JavaFuns();
		if(jf.execute("update forumquestions set dislikes=dislikes+1 where quid='"+request.getParameter("quId").toString().trim()+"'")) {}
		}
		catch (Exception e) {
			System.out.println("err="+e.getMessage());
			// TODO: handle exception
		}
		return "posts";
	}
	@RequestMapping("/home")
	public String home()
	{
		return "index.jsp";
	}
	@RequestMapping("/adminHome")
	public String adminHome()
	{
		return "Admin.jsp";
	}
	@RequestMapping("/ApproveQues1")
	public String ApproveQues1(HttpServletRequest request)
	{
		try
		{
			JavaFuns jf=new JavaFuns();
			System.out.println("update forumquestions set sts='Regular' where quid='"+request.getParameter("quesid").trim()+"' and question='"+request.getParameter("ques").trim()+"'");
			if(jf.execute("update forumquestions set sts='Regular' where quid='"+request.getParameter("quesid").trim()+"' and question='"+request.getParameter("ques").trim()+"'"))
			{
				
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return "Success1.jsp?type=ApproveQues";
	}
	@RequestMapping("/DeleteQues")
	public String DeleteQues(HttpServletRequest request)
	{
		try
		{
			JavaFuns jf=new JavaFuns();
			if(jf.execute("delete from forumquestions  where quid='"+request.getParameter("quesid").trim()+"' and question='"+request.getParameter("ques").trim()+"'"))
			{
				
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return "Success1.jsp?type=DeleteQues";
	}
	@RequestMapping("/ApproveAns")
	public String ApproveAns(HttpServletRequest request)
	{
		try
		{
			JavaFuns jf=new JavaFuns();
			if(jf.execute("update forumanswers set sts='Regular' where quid="+request.getParameter("quesid").trim()+" and anid="+request.getParameter("anid").trim()+" and answer='"+request.getParameter("ans").trim()+"'"))
			{
				
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return "Success1.jsp?type=ApproveAns";
	}
	@RequestMapping("/DeleteAns")
	public String DeleteAns(HttpServletRequest request)
	{
		try
		{
			JavaFuns jf=new JavaFuns();
			if(jf.execute("delete from forumanswers where quid='"+request.getParameter("quesid").trim()+"' and anid='"+request.getParameter("anid").trim()+"' and answer='"+request.getParameter("ans").trim()+"'"))
			{
				
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return "Success1.jsp?type=DeleteAns";
	}
	@RequestMapping("/fromPythonDataset")
	public String fromPythonDataset()
	{
		return "SuccessDataset.jsp";
	}
	@RequestMapping("/staffhome")
	public String staffHome()
	{
		return "Staff.jsp";
	}
	@RequestMapping("/staffHome")
	public String staffHome1()
	{
		return "Staff.jsp";
	}
	@RequestMapping("/studenthome")
	public String studentHome()
	{
		return "Student.jsp";
	}
	@RequestMapping("/studentHome")
	public String studentHome1()
	{
		return "Student.jsp";
	}
	@RequestMapping("/registerstudent")
	public String registerstudent()
	{
		return "Register.jsp";
	}
	 @RequestMapping("/error")
    public String handleError() {
        //do something like logging
		return "college";
    }
 
    
    public String getErrorPath() {
        return "/error";
    }
     
		 
	@RequestMapping("/registeruser")
	public String registeruser(Student stu,ServletRequest request)
	{
		 try
		 {MultipartFile file=stu.getFile();
		 String filepath=request.getServletContext().getRealPath("/")+"/Uploads/";
		 
		 
		 System.out.println("path="+filepath);
		 File f=new File(filepath);
		 f.mkdir();
		  
		 try {
			  
			 String fileName=stu.getUserid()+"."+ file.getOriginalFilename().split("\\.")[1];
			 file.transferTo(new File(filepath+"/"+fileName));
			 stu.setPath(fileName);
			 String st=stu.addNewStudent();
				if(st.equals("success"))
					return "UserRegSuccess.jsp";
				else
					return "UserRegFailure.jsp";
		 }
		 catch (Exception e) {
			// TODO: handle exception
			 return "UserRegFailure.jsp";
		}}
		 catch (Exception e) {
				// TODO: handle exception
			 return "UserRegFailure.jsp";
			}
		
	}
	@RequestMapping("/updateuser")
	public String updateuser(Student stu,ServletRequest request,HttpSession ses)
	{String fileName="NA";
		 try
		 {
			 stu.setUserid(ses.getAttribute("userid").toString().trim());
			 
		  
		 try {
			 MultipartFile file=stu.getFile();
			 String filepath=request.getServletContext().getRealPath("/")+"/Uploads/";
			 
			 
			 System.out.println("path="+filepath);
			 File f=new File(filepath);
			 f.mkdir();
			  fileName=stu.getUserid()+"."+ file.getOriginalFilename().split("\\.")[1];
			 file.transferTo(new File(filepath+"/"+fileName));
			 
		 }
		 catch (Exception e) {
			// TODO: handle exception
			// return "UserRegFailure.jsp";
		}
		 if(!fileName.equals("NA"))
		 {
			 ses.setAttribute("photo", fileName);
		 }
		 stu.setPath(fileName);
		 String st=stu.updateStudent(stu.getUserid());
			if(st.equals("success"))
				return "Success.jsp";
			else
				return "Failure.jsp";
		 }
		 catch (Exception e) {
			 System.out.println("in update="+e.getMessage());
				// TODO: handle exception
			 return "Failure.jsp";
			}
		
	}
	@RequestMapping("/updatestaff")
	public String updatestaff(Staff1 stu,ServletRequest request,HttpSession ses)
	{String fileName="NA";
		 try
		 {
			 stu.setUserid(ses.getAttribute("userid").toString().trim());
			
		 try {
			 MultipartFile file=stu.getFile();
			 String filepath=request.getServletContext().getRealPath("/")+"/Uploads/";
			 
			 
			 System.out.println("path="+filepath);
			 File f=new File(filepath);
			 f.mkdir();
			  
			  fileName=stu.getUserid()+"."+ file.getOriginalFilename().split("\\.")[1];
			 file.transferTo(new File(filepath+"/"+fileName));
			 
		 }
		 catch (Exception e) {
			// TODO: handle exception
			// return "UserRegFailure.jsp";
		}
		 if(!fileName.equals("NA"))
		 {
			 ses.setAttribute("photo", fileName);
		 }
		 stu.setPath(fileName);
		 String st=stu.updateStaff(stu.getUserid());
			if(st.equals("success"))
				return "Success.jsp";
			else
				return "Failure.jsp";
		 }
		 catch (Exception e) {
			 System.out.println("in update="+e.getMessage());
				// TODO: handle exception
			 return "Failure.jsp";
			}
		
	}
	@RequestMapping("/ChangePass")
	public String ChangePass()
	{
		return "ChangePass.jsp";
	}
	@RequestMapping("/ChangePassService")
	public String ChangePassService(Pass eobj,HttpSession ses)
	{
		 
		 try
		 {
			 
			 eobj.setUserid(ses.getAttribute("userid").toString().trim());
			 if(eobj.changePassword())
			 {
				 
				 
				 return "Success.jsp?type=ChangePass";
			 }
			 else
			 { 
				 return "Failure.jsp?type=ChangePass";
			 }
		 }
		 catch (Exception e) {
			// TODO: handle exception
			 System.out.println("err="+e.getMessage());
			 return("Failure.jsp?type=Auth");
		}
		 
	}

	@RequestMapping("/registernewstaff")
	public String registernewstaff(Staff f)
	{
		String st=f.addNewStaff();
		if(st.equals("success"))
			return "Success.jsp";
		else
			return "Failure.jsp";
	
	}
	
	@RequestMapping("/check")
	public String check(CheckUser cu,HttpServletRequest request) {
		
		String st=cu.checkUser(request);
		
		return st;
	}
	
	@RequestMapping("/registerstaff")
	@SessionScope
	public String registerstaff()
	{
		return "RegisterStaff.jsp";
	}
	
	@RequestMapping("/viewstaff")
	@SessionScope
	public ModelAndView viewstaff() {
		List<ViewStaff> lst=new ArrayList<ViewStaff>();
		ViewStaff vs = new ViewStaff();
		lst=vs.getStaff();
		ModelAndView mv=new ModelAndView();
		mv.addObject("stf",lst);
		mv.setViewName("ViewStaffReport.jsp");
		return mv;
	}
	 
	@RequestMapping("/viewRecommArticles")
	@SessionScope
	public ModelAndView viewRecommArticles(HttpSession ses) {
		NewArticle articles=new NewArticle();
		articles.setBranch(ses.getAttribute("branch").toString().trim());
		articles.setSem(ses.getAttribute("sem").toString().trim());
		List<NewArticle> lst = new ArrayList<NewArticle>(); 
		lst=articles.getArticles(ses.getAttribute("userid").toString().trim());
		ModelAndView mv=new ModelAndView();
		mv.addObject("lst",lst);
		mv.setViewName("RecommArticles.jsp");
		return mv;
	} 
	@RequestMapping("/viewstudent")
	@SessionScope
	public ModelAndView viewstudent() {
		
		List<ViewStudent> lst = new ArrayList<ViewStudent>();
		ViewStudent vs = new ViewStudent();
		lst=vs.getStudentReport();
		ModelAndView mv=new ModelAndView();
		mv.addObject("std",lst);
		mv.setViewName("ViewStudentReport.jsp");
		return mv;
	}
	@RequestMapping("/editProfile")
	@SessionScope
	public ModelAndView editProfile(HttpSession ses) {
		ModelAndView mv=new ModelAndView();
		try
		{
		List<Student> lst = new ArrayList<Student>();
		Student vs = new Student();
		lst=vs.getStudentReport(ses.getAttribute("userid").toString().trim());
		
		mv.addObject("std",lst);
		}
		catch (Exception e) {
		System.out.println("errr in edit="+e.getMessage());
		}
		mv.setViewName("EditProfileStud.jsp");
		return mv;
	}
	@RequestMapping("/editProfile1")
	@SessionScope
	public ModelAndView editProfile1(HttpSession ses) {
		
		List<Staff> lst = new ArrayList<Staff>();
		Staff vs = new Staff();
		lst=vs.getStaff(ses.getAttribute("userid").toString().trim());
		ModelAndView mv=new ModelAndView();
		mv.addObject("std",lst);
		mv.setViewName("EditProfileStaff.jsp");
		return mv;
	}
	@RequestMapping("/approvestudentlist")
	@SessionScope
	public ModelAndView approvestudentlist() {
		
		List<ViewStudentList> lst = new ArrayList<ViewStudentList>();
		ViewStudentList vls= new ViewStudentList();
		
		lst=vls.getapprovalList();
		ModelAndView mv=new ModelAndView();
		mv.addObject("stal",lst);
		mv.setViewName("UpdateStudentStatus.jsp");
		return mv;
	
	}
	@SessionScope
	@RequestMapping("/viewexstudent")
	public ModelAndView viewexstudent() {
		
		List<ViewStudent> lst = new ArrayList<ViewStudent>();
		ViewStudent vs = new ViewStudent();
		lst=vs.getExStudentReport();
		ModelAndView mv=new ModelAndView();
		mv.addObject("exstd",lst);
		mv.setViewName("ViewExStudentReport.jsp");
		return mv;
	}
	 
	@RequestMapping("/registerbranch")
	@SessionScope
	public String registerbranch() {
		
		return("RegisterBranch.jsp");
		
	}
	
	@RequestMapping("/registernewbranch")
	public String registernewbranch(RegisterBranch rb) {
		String st;
		try {
		 st=rb.registerBranch();
		}
		catch (Exception e) {
		 System.out.println("err="+e.getMessage());
		 st="duplicate";
		}
		return st;
	}
	@RequestMapping("/regComment")
	public String registernewbranch(Comments rb) {
		String st;
		try {
		 st=rb.registerComment();
		}
		catch (Exception e) {
		 System.out.println("err="+e.getMessage());
		 st="duplicate";
		}
		return st;
	}
	@RequestMapping("/viewComments")
	public ModelAndView viewComments(Comments f,HttpServletRequest request,HttpSession ses) {
		
		List<Comments> lst = new ArrayList<Comments>();
		Comments fh = new Comments();
		f.setBid(Integer.parseInt(request.getParameter("bid").toString().trim()));
		lst=fh.getComments(f.getBid());
		ModelAndView mv=new ModelAndView();
		mv.addObject("forum",lst);
		mv.setViewName("Comments.jsp");
		return mv;
		
	}
	 
	@RequestMapping("/activatestudent")
	public String activatestudent(String uid) {
		
		ApproveStudents ap=new ApproveStudents();
		String sts=ap.updateStudentStatus(uid);
				
		return(sts);
	} 
	@RequestMapping("/enterforum")
	public ModelAndView enterforum(Blogs f,HttpSession ses) {
		
		List<Blogs> lst = new ArrayList<Blogs>();
		Blogs fh = new Blogs();
		lst=fh.getBlogs(ses.getAttribute("branch").toString().trim());
		ModelAndView mv=new ModelAndView();
		mv.addObject("forum",lst);
		mv.setViewName("Posts.jsp");
		return mv;
		
	}
	@RequestMapping("/posts")
	public ModelAndView posts(Blogs f,HttpSession ses) {
		
		List<Blogs> lst = new ArrayList<Blogs>();
		Blogs fh = new Blogs();
		lst=fh.getBlogs(ses.getAttribute("branch").toString().trim());
		ModelAndView mv=new ModelAndView();
		mv.addObject("forum",lst);
		mv.setViewName("Posts.jsp");
		return mv;
		
	}
	@RequestMapping("/searchposts")
	public ModelAndView searchposts(Blogs f,HttpServletRequest request,HttpSession ses) {
		
		List<Blogs> lst = new ArrayList<Blogs>();
		Blogs fh = new Blogs();
		lst=fh.getBlogsSearch(request.getParameter("search").toString().trim());
		ModelAndView mv=new ModelAndView();
		mv.addObject("forum",lst);
		mv.setViewName("Posts.jsp");
		return mv;
		
	}
	@RequestMapping("/viewDetails")
	public ModelAndView viewDetails(Blogs f,HttpSession ses,HttpServletRequest request) {
		
		List<Blogs> lst = new ArrayList<Blogs>();
		Blogs fh = new Blogs();
		lst=fh.getBlogs1(request.getParameter("bid").toString().trim());
		ModelAndView mv=new ModelAndView();
		mv.addObject("forum",lst);
		mv.setViewName("Details.jsp");
		return mv;
		
	}
	@SessionScope
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		LoginTracker lt=new LoginTracker();
		lt.recordLogout(session.getAttribute("userid").toString().trim());
        session.invalidate();
		return "Logout.jsp";
	}
	@RequestMapping("/registerBlog")
	@SessionScope
	public String registerBlog() {
		
		return("RegBlog.jsp");
		
	}
	
	@RequestMapping("/registerblog")
	public String registerblog(NewBlogReg fqg,HttpServletRequest request, HttpSession ses) {
		
		String sts="Failure.jsp"; 
		try
		 {
			MultipartFile file=fqg.getFile();
			JavaFuns jf=new JavaFuns();
			int bid=jf.FetchMax("bid", "blogs");
		 String filepath=request.getServletContext().getRealPath("/")+"/UploadBlogs/";
		 
		 
		 System.out.println("path="+filepath);
		 File f=new File(filepath);
		 f.mkdir();
		 String fileName="NA";
		 try {
			  
			 fileName=bid+"."+ file.getOriginalFilename().split("\\.")[1];
			 file.transferTo(new File(filepath+"/"+fileName));
		 }
		 catch (Exception e) {
			// TODO: handle exception
			 System.out.println("err1="+e.getMessage());
		}
		fqg.setBid(bid);
		fqg.setPhoto(fileName);
		fqg.setBranch(ses.getAttribute("branch").toString().trim());
		fqg.setSem(ses.getAttribute("sem").toString().trim());
		fqg.setUserid(ses.getAttribute("userid").toString().trim());
		fqg.setUsername(ses.getAttribute("username").toString().trim());
		fqg.setUsertype(ses.getAttribute("usertype").toString().trim());
		sts=fqg.register();
		if(sts.equals("Success.jsp"))
		{
			//String param=fqg.getQuestion()+"|"+fqg.getQuid()+"|"+fqg.getSts()+"|"+ses.getAttribute("userid").toString()+"|"+ses.getAttribute("usertype").toString()+"|"+ses.getAttribute("branch").toString()+"|"+ses.getAttribute("photo").toString();
			//Base64Encoder encoder=new Base64Encoder();
			//param=encoder.encode(param.getBytes());
			//return "forward.jsp?page=ForumQues&param="+param;
		}
		else
		{
		
		}
		 }
		 catch (Exception e) {
			// TODO: handle exception
			 System.out.println("err="+e.getMessage());
		}
		return sts;
	}
	  
	 
	@RequestMapping("/newarticle")
	@SessionScope
	public String newarticle() {
		
		return("ArticleUpload.jsp");
	}
	 
	@RequestMapping("/uploadnewarticle")
	public ModelAndView uploadnewarticle(HttpSession ses,@RequestParam("file") MultipartFile file,HttpServletRequest request) {
		String result="Failure.jsp";
		String message="";
		String desc = request.getParameter("description");
		String userid=request.getParameter("userid");
		String title=request.getParameter("title");
		ModelAndView mv=new ModelAndView();
		try 
    	{ 
        if (!file.isEmpty()) 
        {

        	try 
        	{
        		Date date1 = Calendar.getInstance().getTime();  
        	    DateFormat dateFormat = new SimpleDateFormat("hhmmss");  
        	    String ins = dateFormat.format(date1);
        	    
        		int maxid=Integer.parseInt(ins);
        		
        	String filePath = request.getServletContext().getRealPath("/").concat("Uploads");                
            System.out.println("Image Location:" + filePath);
            
            File dir=new File(filePath);
            if(!dir.exists())
                dir.mkdirs();
            
            
            
            int ind=file.getOriginalFilename().lastIndexOf(".");                
            String ext=file.getOriginalFilename().substring(ind+1);        
            String newfileName="file"+maxid+"."+ext; 
            
            File oldfile=new File(filePath+"/" + newfileName);
            if(oldfile.exists()) {
            	oldfile.delete();
            	System.out.println("Old File deleted.."+newfileName);
            }
            
            // Get the file and save it somewhere
            byte[] bytes = file.getBytes();
            Path path = Paths.get(filePath+"/" + newfileName);
            Files.write(path, bytes);
            
            System.out.println("You have successfully uploaded '" + file.getOriginalFilename() + "' - "+newfileName);
            
            NewArticle nw = new NewArticle();
            nw.setPath(request.getServletContext().getRealPath("/"));
            nw.setTitle(title);
            nw.setSem(request.getParameter("sem"));
            nw.setBranch(ses.getAttribute("branch").toString());
            nw.setUsername(ses.getAttribute("username").toString());
            result=nw.uploadArticle(userid, newfileName, desc);
            result="Success1.jsp?type=article&cate="+nw.getCategory();
            //--------------------------------------------------------------------
            

        } 
        catch (IOException e) 
        {            
            System.out.println("Error : "+e);
			result="Failure.jsp";
			message="IO Error : "+e;
        }
        }
        else   
        {     	
        	System.out.println("Please select a file to upload");
        	result="Failure.jsp";
        	message="Please select a file to upload..";
        }
    	}
		catch(Exception ex) 
		{
			System.out.println("Error : "+ex);
			result="Failure.jsp";
			message="Error : "+ex;
		}
		
		mv.addObject("message", message);
		mv.setViewName(result);
		return mv;
	} 
	 
	@RequestMapping("/forgetpassword")
	public String forgetpassword() {
		
		return("ForgetPassword.jsp");
	}
	
	 
	
	@RequestMapping("/recoverpassword")
	public String recoverpassword(PasswordRecovery pr) {
		
		String sts=pr.getNewPassword();
		
		return(sts);
	}
	 
	 
	
}
