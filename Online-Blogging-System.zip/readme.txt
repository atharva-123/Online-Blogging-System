Install jdk
-----------------------------------------------------------------

1] install java17  from jdk file along with jre


-----------------------------------------------------------------
Copy Eclipse IDE 2022-06
-----------------------------------------------------------------

1] Make sure that java17 is installed and running 

2] Copy Eclipse IDE 2022-06 for Java EE  
3] Set java path
----------------------------------------------------------------
Restore database
----------------------------------------------------------------
1] Install MySQL 8 along with Mysql workbench 8 

2] Goto MySQL Administration

3]select Data Import

4]browse/Open Backup file 

5]Start Import


----------------------------------------------------------------
 
-----------------------------------------------------------------  
Execution of Project
-----------------------------------------------------------------
1] Open  Online-Blogging-System in Eclipse IDE
	-Open Eclipse IDE
	-Goto File
	-Open Project from directory
	-Select Online-Blogging-System application

 
2] Run the projects
	->right click on the project that you want to run
	->click on Run As->Java Project-> select your project name from list 
	->click on ok
	->open browser->type url localhost:8080/home 

 


localhost:8080/home
 
----------------------------------------------------------------

www.sohamglobal.com
 

 